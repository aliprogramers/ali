let a = 5
let p=  new Number(5)
console.log(a,p);