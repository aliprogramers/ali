// // let s = new Set([{
// //     id: 1,
// //     name: 'majid'
// // },
// // {
// //     id: 1,
// //     name: 'majid'
// // }])
// // console.log(s);
// // let jon= {name:'jone'}
// // let monika= {name:'monika'}
// // let majid= {name:'majid'}
// // let sett = new Set()
// // sett.add(jon).add(monika).add(majid)
// // console.log(sett);
// // let s = new Set()
// // s.add('010').add('001').add('100')
// // // console.log(s.delete('100'))
// // // console.log(s.has('001'))

// // // console.log(s);
// // let s1 = new Set()
// // s1.add('elh').add('hel').add('leh')
// // let s3 = new Set()
// // for (let item of s) {
// //     s3.add([item])
// // }
// // for (let item2 of s1) {
// //     s3.add([item2])
// // }
// // console.log(s3);
// let arr = [
//     true, false,  
//     {

//         name: 'majid'
//     },
//     {

//         name: 'majid'
//     },
//     {

//         name: 'majid'
//     },
//     {

//         name: 'majid'
//     },
//     {

//         name: 'majid'
//     },
//     {

//         name: 'majid'
//     },
//     {

//         name: 'majid'
//     },
//     {

//         name: 'majid'
//     },
//     {

//         name: 'majid'
//     },
//     {

//         name: 'majid'
//     },
//     {

//         name: 'majid'
//     },
//     {

//         name: 'majid'
//     },
//     {

//         name: 'majid'
//     },
//     {

//         name: 'majid'
//     },
//     {

//         name: 'majid'
//     },
//     {

//         name: 'majid'
//     },
//     {

//         name: 'majid'
//     },
//     {

//         name: 'majid'
//     },
    
     

// ]
// let i = 0
// for (let key of arr) {

//     if (arr[i] == arr[++i]) {
//         arr.splice(i, 1)
//     }


// }
// for (let item of arr) {
//     for (let keyt in item) {
//         if (item[keyt] == item[keyt]) {
//             if (keyt == keyt) {
//                 let t = arr.indexOf(item)
//                 console.log(t);
//                 (arr.splice(t, 1,))
//             }
//         }
//     }
// }
// console.log(arr); 
