
let cotegor6 = {}

let cotegorys = {}
let kotegory = {
    cotegory: {
        id: 1,
        name: 'hello world',
        move: {

            id: 1,
            name: 'bir',

            price: 100,
            calcUltimatePrice: ' ',


        },
        move2: {

            id: 2,
            name: 'ikki',

            price: 200,
            calcUltimatePrice: ' ',


        }



    },
    cotegory2: {
        id: 2,
        name: 'hello world',
        move: {

            id: 1,
            name: 'uch',

            price: 200,
            calcUltimatePrice: ' ',


        },
        move2: {

            id: 2,
            name: 'tort',

            price: 150,
            calcUltimatePrice: ' ',


        }



    }
}


let cotegor = {}
let cotegor2 = {}
let cotegor3 = {}
let cotegor4 = {}
let cotegor5 = {}

let cocumbers = {
    cotegorys2: {
        id: 1,
        cotegoryid: 1,
        count: 2,
        total: 0,
        name: ' '
    }
}
for(let key in kotegory){
    for(let key2 in kotegory[key]['kotegory']){
        Object.assign(cotegor3 = cocumbers.cotegorys2.id = kotegory.cotegory.id)
        console.log('id', cotegor3);

for(let key3 in kotegory[key]['kotegory']['move']){
    Object.assign(cotegor = cocumbers.cotegorys2.cotegoryid = kotegory.cotegory.move.id)
    Object.assign(cotegor5 = cocumbers.cotegorys2.name = kotegory.cotegory.move.name)
    console.log('foodid', cotegor);
    console.log('name', cotegor5);
}
for(let key3 in kotegory[key]['kotegory']['move2']){
    Object.assign(cotegor = cocumbers.cotegorys2.cotegoryid = kotegory.cotegory.move.id)
    Object.assign(cotegor5 = cocumbers.cotegorys2.name = kotegory.cotegory.move.name)
    console.log('foodid', cotegor);
    console.log('name', cotegor5);
}
    }
    for(let key2 in kotegory[key]['kotegory2']){
        Object.assign(cotegor3 = cocumbers.cotegorys2.id = kotegory.cotegory.id)
        console.log('id', cotegor3);
    }
}
console.log(kotegory);
// for (let keys in kotegory) {





//                     Object.assign(cotegor = cocumbers.cotegorys2.cotegoryid = kotegory.cotegory.move.id)
//                     Object.assign(cotegor2 = cocumbers.cotegorys2.count)
//                     Object.assign(cotegor3 = cocumbers.cotegorys2.id = kotegory.cotegory.id)
//                     Object.assign(cotegor4 = cocumbers.cotegorys2.total = kotegory.cotegory.move.price / 100 * 10 * cocumbers.cotegorys2.count )
//                     Object.assign(cotegor5 = cocumbers.cotegorys2.name = kotegory.cotegory.move.name)
//                     Object.assign(cotegor = cocumbers.cotegorys2.cotegoryid = kotegory.cotegory2.move.id)
//                     Object.assign(cotegor2 = cocumbers.cotegorys2.count)
//                     Object.assign(cotegor3 = cocumbers.cotegorys2.id = kotegory.cotegory2.id)
//                     Object.assign(cotegor4 = cocumbers.cotegorys2.total = kotegory.cotegory2.move.price / 100 * 10 * cocumbers.cotegorys2.count)
//                     Object.assign(cotegor5 = cocumbers.cotegorys2.name = kotegory.cotegory2.move.name)

                
            
//         }
    
    
   
        // console.log('count', cotegor2);
        // console.log('total', cotegor4);

// for (let key in kotegory.cotegory.move) {
//     Object.assign(cotegor = cocumbers.cotegorys2.cotegoryid = kotegory.cotegory.move.id)
//     Object.assign(cotegor2 = cocumbers.cotegorys2.count = kotegory.cotegory.move.count)
//     Object.assign(cotegor3 = cocumbers.cotegorys2.id = kotegory.cotegory.id)
//     Object.assign(cotegor4 = cocumbers.cotegorys2.total = kotegory.cotegory.move.price / 100 * 10 * kotegory.cotegory.move.count)
//     Object.assign(cotegor5 = cocumbers.cotegorys2.name = kotegory.cotegory.move.name)
//     Object.assign(cotegor = cocumbers.cotegorys2.cotegoryid = kotegory.cotegory2.move.id)
//     Object.assign(cotegor2 = cocumbers.cotegorys2.count = kotegory.cotegory2.move.count)
//     Object.assign(cotegor3 = cocumbers.cotegorys2.id = kotegory.cotegory2.id)
//     Object.assign(cotegor4 = cocumbers.cotegorys2.total = kotegory.cotegory2.move.price / 100 * 10 * kotegory.cotegory.move.count)
//     Object.assign(cotegor5 = cocumbers.cotegorys2.name = kotegory.cotegory2.move.name)



// }
// console.log('id', cotegor3);
// console.log('foodid', cotegor);
// console.log('count', cotegor2);
// console.log('total', cotegor4);
// console.log('name', cotegor5);