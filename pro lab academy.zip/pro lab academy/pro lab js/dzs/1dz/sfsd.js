// zadacha (1){

// function dobavit(surname,ochestvo,year){
// let nome = {
//     familiya:surname,
//     ochestvos:ochestvo,
//     year : year,
//     age:function yours(){
//         return 2023 - this.year
//     },
    
// }
// console.log(nome);

// }
// dobavit('bakirganov','bakirganovnovich',2008)


//}



//zadacha(4){
// let obj={
//     name:"abdulhay",
//     suname:"bakirganov",
//     age:17,
//     job:"it",
// }

// let length = 0
// for(let key in obj){
//     length++
// }
// function name(params) {
    
// }
// obj['obj' + (length + 1)]= {
//     id: length + 1,
//     namee: 'name',
//     surnamse: 'suname',
//     age: 17,
//     job: ' i t',
// }
// console.log(length);

//}
// zadacha (3)

                              // let obj={
                              //     "b":2,
                              //     "i":'+',
                              //     "u":6,
                              //     "t":' ',
                              // }

                              // if(obj.i == '*'){
                              //     t = obj.b * obj.u
                              //     console.log(t);
                              // }

                              // else if(obj.i == '+'){
                              //     t = obj.b + obj.u
                              //     console.log(t);
                              //  }

                              //  else if(obj.i == '-'){
                              //     t = obj.b - obj.u
                              //     console.log(t);
                              //  }

                              // else if(obj.i == '/'){
                              //     t = obj.b / obj.u
                              //     console.log(t);
                              //  }









                              








//zadacha(7){


// let fosfd = 0
// let categories = {
//     category: {
//         id: 1,
//         name: "Hot Dish",
//         foods: {
//             food: {

//                 id: 1,
//                 name: "Bifshteks",
//                 price: 38,
//                 discount: 20,
//                 count: 4,``   2
//                 consst:200,

//                 calcUltimatePrice: function () {
//                     return (this.price / 100) * this.discount

//                 }


//             },
//             food2: {

//                 id: 2,
//                 name: "Pelmen",
//                 price: 68,
//                 discount: 40,
//                 count: 7,
//                 consst:300,
//                 calcUltimatePrice: function () {
//                     bil += discount
//                     money -= bil
//                     console.log(money);

//                     return (this.price / 100) * this.discount
//                 }
//             }
//         }
//     }
// }



// function dletetcategories(ids) {
//    for(let kes in categories.category.foods)
//    if(ids == 1){
//       console.log(categories.category.foods.food);


//       function dletetcaies(idsr) {
//          for(let kes in categories.category.foods)
//          if(idsr == 1){
//             console.log(categories.category.foods.food.name);
//          }
//         else if(idsr == 2){
//             console.log(categories.category.foods.food2.consst);
//          }
//          // for (let key in categories) {
//          //     if(ids = categories[key][' id']){
      
      
//          //     }
//          // }
         
//       }
//       dletetcaies(2)
      

//       function tcategories(idsf) {
//          for(let kes in categories.category.foods)
//          if(idsf == 1){
//             console.log(categories.category.foods.food.name);
//          }
//         else if(idsf == 2){
//             console.log(categories.category.foods.food2.consst);
//          }
//          // for (let key in categories) {
//          //     if(ids = categories[key][' id']){
      
      
//          //     }
//          // }
         
//       }
//       tcategories(1)
      

   
//    }

//   else if(ids == 2){
//       console.log(categories.category.foods.food2);


//       function dletetcaies2(idsrs) {
//          for(let kes in categories.category.foods)
//          if(idsrs == 1){
//             console.log(categories.category.foods.food.name);
//          }
//         else if(idsrs == 2){
//             console.log(categories.category.foods.food2.consst);
//          }
//          // for (let key in categories) {
//          //     if(ids = categories[key][' id']){
      
      
//          //     }
//          // }
         
//       }
//       dletetcaies2(2)
      

//       function tcategories2(idsfs) {
//          for(let kes in categories.category.foods)
//          if(idsfs == 1){
//             console.log(categories.category.foods.food.name);
//          }
//         else if(idsfs == 2){
//             console.log(categories.category.foods.food2.consst);
//          }
//          // for (let key in categories) {
//          //     if(ids = categories[key][' id']){
      
      
//          //     }
//          // }
         
//       }
//       tcategories2(1)
      







      
//    }
// }
// dletetcategories(2)
//}

//zadacha(6){

// let fosfd = 0
// let categories = {
//     category: {
//         id: 1,
//         name: "Hot Dish",
//         foods: {
//             food: {

//                 id: 1,
//                 name: "Bifshteks",
//                 price: 38,
//                 discount: 20,
//                 count: 4,
//                 calcUltimatePrice: function () {
//                     return (this.price / 100) * this.discount

//                 }


//             },
//             food2: {

//                 id: 2,
//                 name: "Pelmen",
//                 price: 68,
//                 discount: 40,
//                 count: 7,
//                 calcUltimatePrice: function () {
//                     bil += discount
//                     money -= bil
//                     console.log(money);

//                     return (this.price / 100) * this.discount
//                 }
//             }
//         }
//     }
// }
// for(let keys in categories.category.foods.food.name){
   
//    console.log(categories.category.foods.food.name)
// }
// for(let keys in categories.category.foods.food2.name){
//    console.log(categories.category.foods.food2.name)
// }
// console.log();
// console.log(categories.category.foods.food.name);
// console.log(categories.category.foods.food2.name);
//}



