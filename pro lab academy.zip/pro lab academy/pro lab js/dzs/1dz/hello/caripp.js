// let masage = "hello"
// let home = masage
// masage = null
// console.log(home);
// let uzes = {
//     name: 'aziz'
// }
// let humna = uzes
// console.log(humna, uzes);
// console.log(user == humna);
// uzes = null
// console.log(humna);
// let uzser={
//     name:'joh',
//     age:30,

// }
// let lone ={}
// for(let key in uzser ){
//     lone[key] = uzser[key]
    
// }
// lone.name='putek'
// alert(uzser.name)

