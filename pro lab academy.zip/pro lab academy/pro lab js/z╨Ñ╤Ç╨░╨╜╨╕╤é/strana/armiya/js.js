const tajidikstan = {
    armiy:{
        prosent:40.8
    },
    bbc:{
        prosent:9.5
    },
    mp:{
        prosent:5.9
    }
}
// function arimya(A,B,M) {
//     let resutl = 0
//     for(let key in  tajidikstan){
//         if(A == tajidikstan.armiy){
            
//         }
//         console.log(tajidikstan[key]);
//     }
// }

// console.log(arimya(300,100,100,));
function tajidikstan1(A,B,M) {

for(let key in tajidikstan){
    if(A != 0){
  A / 10 + tajidikstan.armiy.prosent

    }
    else  if(B){
        (B / 10) + tajidikstan.bbc.prosent

    } else  if(B != 0){
        (M / 10) + tajidikstan.mp.prosent

    }
   console.log(tajidikstan[key]);

   }
}


tajidikstan1(50,40,60)

console.log(tajidikstan);