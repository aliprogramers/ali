let users = [
    {
        id: 1,
        name: 'akjol',
        status: 1,
        solary: 1000,
        bonus: 5,
        pasword: '123455'
    },
    {
        id: 2,
        name: 'akjol2',
        status: 3,
        solary: 1500,
        bonus: 15,
        pasword: '1223'
    }, {
        id: 3,
        name: 'akjol3',
        status: 1,
        solary: 100,
        bonus: 5,
        pasword: '080'
    }

]
let statuss = [
    {
        id: 1,
        title: 'admin',
    },
    {
        id: 2,
        title: 'subatent',
    },
    {
        id: 3,
        title: 'coputdnim',
    },
    {
        id: 4,
        title: 'aji bashi',
    },
]

// function gs() {
//     let map = new Map()
//     for (let item of statuss) {
//         let objs = []

//         for (let itme2 of users) {
//             if (itme2.status == item.id) {
//                 objs.push(itme2)
//                 map.set(item.title, objs)
//             }
//             else{
//                 map.set(item.title, objs)
//             }
//         }
//     }
//     console.log(map);
// }
// gs()
// let pro = prompt('amg')