let date = new Date().getMilliseconds()
console.log(date);