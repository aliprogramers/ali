// let items = [1, 83, 9, 1, 2, 3, 3, 43, 9,]
// // console.log(item.sort());
// console.log(items.sort((a, b) => a - b));
// console.log(items.sort((a, b) => a - b));
// console.log(item.sort((a.b) =>  a -b ))
// function username(a, b) {
//     // console.log(a,b);
//     // if (a > b) {
//     //     return 1
//     // }
//     // if (a == b) {
//     //     return 0
//     // }
//     // if (a < b) {
//     //     return -1
//     // }
//     return a - b
// }
// username(item.sort(username))
// console.log();
// function integer() {
//     let peremeniy = 0
//     item.filter(itme => {
//         if (itme == Number) {
//             peremeniy = + parseInt(itme)

//         }
//     })
//     console.log(peremeniy);
// }
// integer()


// let ret = [
//     { id: 1, name: "dog", cost: 450, kg: 18, old: 2 },
//     { id: 2, name: "rex-dog", cost: 110, kg: 8, old: 3 },
//     { id: 3, name: "hot-dog", cost: 350, kg: 28, old: 1 },
// ]
// // menga kilosi costga teng boladi ,summani chiqarip ber,yoshi 3 
// function helow() {
//     let  u = {}
//     let your = ret.filter(items=>{
//             return u += items['kg'] * items['cost']
//     })
//     console.log(u.sort());
// }
// helow()
// let a =[1,2,3,4]
// let rtust = a.reduce((paramet,item)=>{
//     return  paramet + item
// },13 )
// console.log(rtust);
// let rr = a.reduce(function(parlet,itme){
//     return itme + parlet
// }, 1)
// console.log(rr);
//  let arr = ['vaniya','ishtvan','ilya']
//  let news = arr;
//  news.push('petya')
//  console.log(arr.length);
 // 4
//   let users =['vanya','ishtvan']
//   users.push('oliya')
//   console.log(users);
// users.splice(1,1,'petya')
// users.splice(0,1,'masha','pasha')
//   console.log(users);
//  let s =  users.join(0)
//   console.log();
// let ke = 's'
// ke.split()
// console.log(ke);
// // masiv
// let ar = [4,44,4]
// let reducevaleu = ar.reduce((ites)=>{
//     console.log(ites);
// })
// //4 