// let categories =[
//     {
//         id:1,
//         name:'horor'
//     },    {
//         id:2,
//         name:'kammediya'
//     },    {
//         id:1,
//         name:'roman'
//     },

// ]
// let films=[
//     {
//         id:1,
//         catid:1,
//         name:'zvonok',
//         cost:200
//     },
//     {
//         id:2,
//         catid:2,
//         name:'tretey liwniy',
//         cost:500
//     },
//     {
//         id:3,
//         catid:3,
//         name:'trimetra mod udeloniya neba',
//         cost:400
//     },
// ]
// let hall = [
//     {
//         id:1,
//         ples:20
//     },
//     {
//         id:2,
//         ples:30
//     },  {
//         id:3,
//         ples:25
//     }
// ]
//  let season = [
//     {
//         id:1,
//         dilmis:1,
//         hallid:2,
//         startdate:'2023-03-01|22:30:60:600',
//         enddate:'2023-03-01|24:30:60:600'
//     },
//     {
//         id:2,
//         dilmis:2,
//         hallid:1,
//         startdate:'2023-03-02|18:30:60:600',
//         enddate:'2023-02-03|20:30:60:600'

//     }
//  ]
//  let categories2=[
//     {
//         id:1,
//         name:'fast food'
//     },
//     {
//         id:2,
//         name:'salat'
//     },
//     {
//         id:3,
//         name:'desert'
//     },
//  ]
//  let custmers=[
//     {
//         id:1,
//         foods:[1,1,2,2]
//     },
//     {
//         id:2,
//         foodsd:[2,2,3,4]
//     }
//  ]
// let foods=[
//     {
//         id:1,
//         name:'cake',
//         cos:100,
//         caitid:1,

//     },
//     {
//         id:2,
//         name:'choloate',
//         cos:150,
//         caitid:1,
        
//     },
//     {
//         id:3,
//         name:'burger',
//         cos:200,
//         caitid:2,
        
//     },
//     {
//         id:4,
//         name:'sezar',
//         cos:250,
//         caitid:3,
        
//     }
// ]

// // let resut = categories2.map(itme=>{
// //     let obj = foods.find((item1)=>{
// //         return 
// //     })
        
// //     console.log(obj);

// // })



// let arr = [10,2,20,'hello',this,'hello']

// function ourfind(arr,calback) {
  
//     let o = arr
//     let len = o.length
//     let k = 0
    
//     while(k<len){
//         let result = calback(o[k],k,o)
//         if(result){
//             return o[k]
//         }
//         k++
//     }

// }
// console.log(
// ourfind(arr,(item,index,array)=>{
//     if(item==20){
//         return item
//     }
// })
// );
// let s = [1,3,43,4,3,4,3,4,13,7,33,34]

// console.log(s.sort());

// let arr = [10,2,20,'hello',this,'hello']
// let araa= []
// function ourfind(arr,calback) {
  
//     let o = arr
//     let len = o.length
//     let k = 0
    
//     while(k<len){
//         let result = calback(o[k],k,o)
//         if(result){
//             araa.push( o[k])
//         }
//         k++
//     }

// }

// let sd = arr.ourfind(arr,(item,index,array)=>{
//     if(item=='hewllo'){
//         return item
//     }
// else{
//     return item
// }})
//     console.log(araa);