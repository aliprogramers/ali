// // let users = [
// //     {
// //         id: 1,
// //         name: "miki",
// //         aate: "2004-02-01T12:30:00"
// //     },
// //     {
// //         id: 2,
// //         name: "nurik",
// //         aate: "2023-06-16T14:45:10"
// //     },
// // ]
// // function sdf(par) {

// //     let s = `${par}`
// //     let t = 0
// //     let y = 0
// //     let ss = s.split(':')
// //     for (let item of ss) {
// //         //   t += item*60*60*1000  
// //         if (ss[0] !== undefined) {
// //             t += ss[0] * 3600 * 1000
// //             if (ss[1] !== undefined) {
// //                 t += ss[1] * 60 * 1000
// //                 if (ss[2] !== undefined) {
// //                     y = ss[2] * 1000
// //                     t += y
// //                     break
// //                 }
// //                 else {
// //                     break
// //                 }
// //             }
// //             else {
// //                 break
// //             }
// //         }
// //         else {
// //             console.log('nechevo');
// //         }



// //     }
// //     // console.log(y);
// //     console.log(t);


// // }
// // sdf('1:')
// // // sdf('20:30:30')
// // // function sdf() {
// // //     // let s = new Date()
// // //     // let ar = []
// // //     // let ss  =0
// // //     // for (let item of users) {
// // //     //     ar.push(s.getTime(users[ss]))
// // //     //     ss++
// // //     // }
// // //     // console.log(ar);


// // //     //     console.log();
// // //     //     for(let item of ar){
// // //     // for(let key in item){
// // //     //     console.log(item[key])
// // //     // }
// // //     //     }
// // // }
// // // sdf()
// // let s = `${draction}`
// // let t = 0
// // let y = 0
// // let ss = s.split(':')
// // for (let itqem of ss) {
// //     //   t += item*60*60*1000  
// //     if (ss[0] !== undefined) {
// //         t += ss[0] * 3600 * 1000
// //         if (ss[1] !== undefined) {
// //             t += ss[1] * 60 * 1000
// //             if (ss[2] !== undefined) {
// //                 y = ss[2] * 1000
// //                 t += y
// //                 break
// //             }
// //             else {
// //                 break
// //             }
// //         }
// //         else {
// //             break
// //         }
// //     }
// //     else {
// //         console.log('nechevo');
// //     }



// // }
// // // console.log(y);
// // // console.log(t);
// // let u = `${date__start}`
// // let e = u.split(':')
// // let arrr = [e]
// // // console.log(arrr);
// // let to = 0
// // let sss = 0
// // for (let itewm of arrr) {
// //     if (e[sss] !== undefined) {
// //         to += e[sss] * 365 * 12 * 31 * 24 * 3600 * 1000
// //         sss++
// //         if (e[sss] !== undefined) {
// //             to += e[sss] * 12 * 31 * 24 * 3600 * 1000
// //             sss++
// //             if (e[sss] !== undefined) {
// //                 to += e[sss] * 31 * 24 * 3600 * 1000
// //                 sss++
// //                 if (e[sss] !== undefined) {
// //                     to += e[sss] * 24 * 3600 * 1000
// //                     sss++

// //                     if (e[sss] !== undefined) {
// //                         to += e[sss] * 3600 * 1000
// //                         sss++

// //                         if (e[sss] !== undefined) {
// //                             to += e[sss] * 60 * 1000
// //                             sss++
// //                             if (e[sss] !== undefined) {
// //                                 to += e[sss] * 1000
// //                                 sss++

// //                                 break
// //                             }

// //                             break

// //                         }
// //                         else {
// //                             break
// //                         }
// //                         break
// //                     }
// //                     else {
// //                         break
// //                     }
// //                     break
// //                 }
// //                 else {
// //                     break
// //                 }
// //                 break
// //             }
// //             else {
// //                 break
// //             }
// //             break
// //         }
// //         else {
// //             break
// //         }
// //         break
// //     }
// //     else {
// //         console.log('nechevo');
// //     }


// // }
// // let su = 0
// // su += to
// // // console.log(su);
// // to += t


// // let w = users[0]['date__start']
// // let ww = w.split(':')
// // let rrr = [ww]
// // let tos = 0
// // let sss1 = 0
// // for (let itewm of rrr) {
// //     if (ww[sss1] !== undefined) {
// //         tos += ww[sss1] * 365 * 12 * 31 * 24 * 3600 * 1000
// //         sss1++
// //         if (ww[sss1] !== undefined) {
// //             tos += ww[sss1] * 12 * 31 * 24 * 3600 * 1000
// //             sss1++
// //             if (ww[sss1] !== undefined) {
// //                 tos += ww[sss1] * 31 * 24 * 3600 * 1000
// //                 sss1++
// //                 if (ww[sss1] !== undefined) {
// //                     tos += ww[sss1] * 24 * 3600 * 1000
// //                     sss1++

// //                     if (ww[sss1] !== undefined) {
// //                         tos += ww[sss1] * 3600 * 1000
// //                         sss1++

// //                         if (ww[sss1] !== undefined) {
// //                             tos += ww[sss1] * 60 * 1000
// //                             sss1++
// //                             if (ww[sss1] !== undefined) {
// //                                 tos += ww[sss1] * 1000
// //                                 sss1++

// //                                 break
// //                             }

// //                             break

// //                         }
// //                         else {
// //                             break
// //                         }
// //                         break
// //                     }
// //                     else {
// //                         break
// //                     }
// //                     break
// //                 }
// //                 else {
// //                     break
// //                 }
// //                 break
// //             }
// //             else {
// //                 break
// //             }
// //             break
// //         }
// //         else {
// //             break
// //         }
// //         break
// //     }
// //     else {
// //         console.log('nechevo');
// //     }


// // }
// // let w1 = users[0]['date__endate']
// // let ww1 = w1.split(':')
// // let rrr1 = [ww1]
// // let tos1 = 0
// // let sss11 = 0
// // for (let iqtem of rrr1) {
// //     if (ww1[sss11] !== undefined) {
// //         tos1 += ww1[sss11] * 365 * 12 * 31 * 24 * 3600 * 1000
// //         sss11++
// //         if (ww1[sss11] !== undefined) {
// //             tos1 += ww1[sss11] * 12 * 31 * 24 * 3600 * 1000
// //             sss11++
// //             if (ww1[sss11] !== undefined) {
// //                 tos1 += ww1[sss11] * 31 * 24 * 3600 * 1000
// //                 sss11++

// //                 if (ww1[sss11] !== undefined) {
// //                     tos1 += ww1[sss11] * 24 * 3600 * 1000
// //                     sss11++

// //                     if (ww1[sss11] !== undefined) {
// //                         tos1 += ww1[sss11] * 3600 * 1000
// //                         sss11++

// //                         if (ww1[sss11] !== undefined) {
// //                             tos1 += ww1[sss11] * 60 * 1000
// //                             sss11++

// //                             if (ww1[sss11] !== undefined) {
// //                                 tos1 += ww1[sss11] * 1000
// //                                 sss11++

// //                                 break
// //                             }

// //                             break
// //                         }
// //                         else {
// //                             break
// //                         }
// //                         break
// //                     }
// //                     else {
// //                         break
// //                     }
// //                     break
// //                 }
// //                 else {
// //                     break
// //                 }
// //                 break
// //             }
// //             else {
// //                 break
// //             }
// //             break
// //         }
// //         else {
// //             break
// //         }
// //         break
// //     }
// //     else {
// //         console.log('nechevo');
// //     }


// // }
// // // console.log(t);
// // // console.log(to);
// // // console.log(tos);
// // // console.log(tos1);

// // let i = 0
// // let i1 = 0
// // let yw  = 0
// // let [, , qqq, ...po] = ww

// // for (let item of po) {
// //   let as  =  parseInt(po[i++])
// //   let sa = parseInt(ss[i1++])
// // yw  = as += sa
// // }
// // console.log(yw);
// // if (tos <= to > tos1) {
// //     console.log('zapolnen');
// // }
// // else if (tos > to) {
// //     if (tos1 > to) {
// //         users.push({
// //             id: 'ew',
// //             date__start: date__start,
// //             date__endate: su
// //         })
// //     }
// // }
// // else if (tos1 < to) {
// //     users.push({
// //         id: 'ew',
// //         date__start: date__start,
// //         date__endate: su
// //     })
// // }




// // // console.log(t);

// // // let sy = new Date()
// // // let ys = 0
// // // ys = + sy.getDate(date__start + t)
// // // // console.log(sy);
// let users = [
//     {
//         id: 1,
//         date__start: '2023:01:02:12:30:00:000Z',
//         date__endate: '2023:01:02:14:30:00:000Z'
//     },
//     {
//         id: 2,
//         date__start: '2023:01:02:16:30:00:000Z',
//         date__endate: '2023:01:02:18:30:00:000Z'
//     },

// ]

// function cared(date__start, draction) {
//     let ne = new Date().getMilliseconds('100')
//     console.log(ne);
//     let s = date__start.split(':')
//     s[0] += 325 * 12 * 31 * 24 * 60 * 60 * 1000
//     s[1] += 12 * 31 * 24 * 60 * 60 * 1000
//     s[2] += 31 * 24 * 60 * 60 * 1000
//     s[3] += 24 * 60 * 60 * 1000
//     s[4] += 60 * 60 * 1000
//     s[5] += 60 * 1000
//     s[6] += 1000
//     let total = 0

//     for (let item of s) {
//         total += parseInt(item)

//     }

//     let ss = draction.split(':')
//     console.log(ss);
//     ss[0] += 60 * 60 * 1000
//     ss[1] += 60 * 1000
//     let total3 = 0
//     for (let item of s) {
//         total3 += parseInt(item)

//     }
//     console.log(total3);
//     for (let item of users) {
//         let start = item.date__start
//         let s = item.date__start.split(':')
//         s[0] += 325 * 12 * 31 * 24 * 60 * 60 * 1000
//         s[1] += 12 * 31 * 24 * 60 * 60 * 1000
//         s[2] += 31 * 24 * 60 * 60 * 1000
//         s[3] += 24 * 60 * 60 * 1000
//         s[4] += 60 * 60 * 1000
//         s[5] += 60 * 1000
//         s[6] += 1000
//         let total1 = 0
//         for (let item of s) {
//             total1 += parseInt(item)

//         }
//         // console.log(total1);
//         let s1 = item.date__endate.split(':')
//         s1[0] += 325 * 12 * 31 * 24 * 60 * 60 * 1000
//         s1[1] += 12 * 31 * 24 * 60 * 60 * 1000
//         s1[2] += 31 * 24 * 60 * 60 * 1000
//         s1[3] += 24 * 60 * 60 * 1000
//         s1[4] += 60 * 60 * 1000
//         s1[5] += 60 * 1000
//         s1[6] += 1000
//         let total2 = 0
//         for (let item of s) {
//             total2 += parseInt(item)

//         }
//         //    console.log(total2);

//     }

//     // console.log();
//     let news1 = new Date()
//     // console.log(news1.getTime(draction))
//     // console.log(news);
//     // console.log(news1);
//     // console.log(news.getTime(draction))

// }
// cared('2020:01:02:12:30:00:000Z', '1:40')
// console.log(users);
// let seanses = [
//     {
//         id: 1,
//         date_from: "2023-01-01T12:30:00.000Z",
//         date_to: "2023-01-01T14:30:00.000Z"
//     },
//     {
//         id: 2,
//         date_from: "2023-01-01T16:30:00.000Z",
//         date_to: "2023-01-01T18:40:00.000Z"
//     },
//     {
//         id: 3,
//         date_from: "2023-01-01T22:40:00.000Z",
//         date_to: "2023-01-02T01:30:00.000Z"
//     },
// ]
// function AddNewSeans(date_from, duration) {
//     let data_start = new Date(date_from).getTime()
//     console.log(new Date(data_start));
//     let n = duration
//     let j = new Date(date_from)
//     j.setHours(j.getHours() + +n.split(':')[0], j.getMinutes() + +n.split(':')[1])
//     let data_end = new Date(j).getTime();
//     console.log(new Date(j));
//     let fixator = 0

//     // j.setHours(j.getHours() + 6)
//     let sortedSeanses = seanses.sort((a, b) => new Date(a.date_from) - new Date(b.date_from))
//     for(let i = 0; i <= sortedSeanses.length - 1 ; i++){
//       if(i == 0){
//         if(data_end < new Date(sortedSeanses[i].date_from).getTime()){
//           seanses.push({
//                     id: seanses.length ? seanses.at(-1).id + 1 : 1,
//                     date_from: date_from,
//                     date_to: new Date(j).toJSON()
//                 })
//           return ;
//         }
//       }

//       if(sortedSeanses[i + 1] === undefined){
//       if(i == sortedSeanses.length - 1){
//         if(data_start > new Date(sortedSeanses[i].date_to).getTime()){
//           seanses.push({
//                     id: seanses.length ? seanses.at(-1).id + 1 : 1,
//                     date_from: date_from,
//                     date_to: new Date(j).toJSON()
//                 })
//           return ;
//         }
//       }
//       console.log("Error");
//       return;
//     }

//       if(new Date(sortedSeanses[i].date_to).getTime() < data_start && new Date(sortedSeanses[i + 1].date_from).getTime() > data_end){
//         seanses.push({
//                     id: seanses.length ? seanses.at(-1).id + 1 : 1,
//                     date_from: date_from,
//                     date_to: new Date(j).toJSON()
//                 })
//           return ;
//       }
//     }


// }
// AddNewSeans("2023-01-01T02:03:00.000Z", "1:54")

// let sortedSeanses = seanses.sort((a, b) => new Date(a.date_from) - new Date(b.date_from))
// console.log(sortedSeanses);
// let hootel = [
//     {
//         id: 1,
//         catid: 1,
//         date_start: '2023:01:02:14:00:000Z',
//         date_end: '2023:01:02:15:50:00:000Z'
//     },
//     {
//         id: 2,
//         catid: 2,
//         date_start: '2023:01:02:12:50:00:000Z',
//         date_end: '2023:01:02:13:50:00:000Z'
//     },
// ];

// let categories = [
//     {
//         id: 1,
//         name: 'ujastik'
//     },
//     {
//         id: 2,
//         name: 'boyevik'
//     }
// ];

// function addhootel(catid, data_starts, duration) {
//     let date__start = new Date(data_starts).getTime()////837367343863784
//     console.log('gfdgfdgd',date__start);

//     let date_end =new Date(data_starts) + new Date(duration).getHours() +new Date(data_starts).getMinutes() + new Date(data_starts).getMinutes()
// console.log(new Date(date_end))
//     console.log(date_end);
//     console.log(date__start);

//     let proverka = undefined
//     for (let item of hootel) {
//         if (item.date_start >= date__start <= item.date_end) {
//             console.log('false');
//             false
//         }
//         else if (item.date_start > date__start && item.date_end > date__start) {
//             console.log('true');
//             proverka = true
//         }
//         else if (item.date_end > date__start) {
//             console.log('true');
//             proverka = true
//         }
//     }


//     if (proverka) {
//         hootel.push({
//             id: ++hootel.length,
//             catid: catid,
//             data_start: data_starts,
//             date_end: date__start
//         })
//     }
// }
// addhootel(1, '2023-01-02', '02:30')
// console.log(hootel);
// function sdf(id) {
//     let objs = discoundt.find(items => items.id == id)
//     let s = new Date(objs.date__start)

//     let r = new Date(s.setDate(s.getDate() + objs.days))
//     objs.date__end = r

// }
// sdf(1)
// console.log(discoundt);

// console.log(new Date('2023, 01, 01').getTime());

let food = [
    { id: 1, cost: 100 },
    { id: 2, cost: 50 },
    { id: 3, cost: 10 },
]
let discoundt = [
    {
        id: 1,
        items: [1, 2],
        date__start: '2023-05-20',
        date__end: '2023-05-22',
        days: '04',
        discoundts: 50
    }
]
let st = 0
let arr = 0
let arr1 = 0
let custmers = [{
    id: 1,
    itmes: [1, 1, 2, 2],
    date: '2023-05-21',
    total: function () {
let total = 0
        for (let itme2 of discoundt) {
            var n = new Date(itme2.date__start).getTime()
            var k = new Date(itme2.date__end).getTime()
            var s = new Date(this.date).getTime()
        }
        for (let items of this.itmes) {
            for (let itme2 of discoundt) {
                for (let itme3 of itme2.items) {
                    if (items == itme3) {
                        for (let itme2 of discoundt) {
                            for (let itme of food) {
                                if (n < s && s < k) {
                                    total+= itme.cost - (itme.cost / 100 * itme2.discoundts)
                                }
                            }
                        }
                    }
                }
                
            }

        }

        return total
 
    }
    
}

]

console.log(custmers.forEach(item => item.total()));
console.log(arr1 / 2.2);