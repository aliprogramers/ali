let objs ={
    name:{
        hna:'sdf'
    }
}
let s = new Map()
s = [objs]
console.log(s);