let word = 'hello'
let word2 = new String('hello my frends')
// console.log(word2.indexOf('ban'));
console.log(word2);
let world='hello ' 
console.log(world.at(-2));
console.log(world.toUpperCase());
console.log(world.toLowerCase());
console.log(world.indexOf('e'));
console.log(world.includes('he'));
console.log(world.startsWith('h'));
console.log(world.endsWith('lo'));
console.log(world.slice(0,2));
console.log(world.substring(4,2));
console.log(world.substr(2,4));
console.log(world.trim('hi'));
console.log(world.repeat(30000000));