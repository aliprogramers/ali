let magazing = {
    NOUT1: {
        id: 1,
        name: 'macbook',
        diyum: '13',
        pamit: '500 GB',
        OPERATIVKA: '8GB'
    }, NOUT2: {
        id: 2,
        name: 'THIKPAD',
        diyum: '14',
        pamit: '256 GB',
        OPERATIVKA: '8GB'
    }, NOUT3: {
        id: 3,
        name: 'ACER',
        diyum: '15',
        pamit: '256 GB',
        OPERATIVKA: '4GB'
    }
}
console.log('😏');