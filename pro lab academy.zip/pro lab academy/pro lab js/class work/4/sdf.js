// let pesson = {
//     namee:"abdulaziz",
//     age:16

// }

// let pesson2 = {
//     namee:"majid",
//     age:17

// }
// console.log(pesson['age']);
// console.log(pesson['namee']);
// let car = {}
// car['tipe'] = 'avtomat'
// car['rice'] = 1000
// console.log(car);
// car['color'] = 'red'
// console.log(car);
// let uzer = {
//     name:'abdulaziz',
//     surname: 'bakirganov'
// }
// alert('name' in uzer)
// let person = {
//     namee:"aziz",
//     age:30,
//     pol:'man'
// }
// delete person.namee
// for(let key in person){
//     alert(person[key])
// }


















// let user = {
//     user1: {
//         id: 1,
//         namee: 'kkdkdk',
//         surname: 'dfjdkf',
//         age: '23',
//         job: 'it'
//     },
//     user2: {
//         id: 2,
//         namee: 'kkdkdwdwek',
//         surname: 'dfjdkwewewewf',
//         age: '293',
//         job: 'itt'
//     }

// }
// function ask(name, surname, age, job) {
    
// let length = 0
// for(let key in user){
//     length++
// }
// user['user' + (length + 1)]= {
//     id: length + 1,
//     namee: name,
//     surname: surname,
//     age: age,
//     job: job,
// }
// }
// ask("lskdfjlksd", 'sdfjlsdfjlksdfjf', 12, 'ojkdfjk')



// function delet(id, name, surname,age,job) {
//     for(let key in user){
//         if(id == user [key]['id']){
//             user[key]['name']= name,
//             user[key]['suname']= surname,
//             user[key]['age']= age,
//             user[key]['job']= job
//         }
//     }
// }
// delet(1,'huy','djfkldf',23,'dfjdlkj')
// function dletetuser(id) {
//     for(let key in user){
//         if(id == user[key]['id']){
//             delete user[key]
//         }
//     }
// }
// dletetuser(1)
// console.log(user);









let users = {
    user1: {
        id: 1,
        namee: 'kkdkdk',
        surname: 'dfjdkf',
        age: '23',
        job: 'it'
    },
    user2: {
        id: 2,
        namee: 'kkdkdwdwek',
        surname: 'dfjdkwewewewf',
        age: '293',
        job: 'itt'
    }

}
function ask(name, surname, age, job) {
    
let length = 0
for(let key in users){
    length++
}
users['users' + (length + 1)]= {
    id: length + 1,
    namee: name,
    surname: surname,
    age: age,
    job: job,
}
}
ask("lskdfjlksd", 'sdfjlsdfjlksdfjf', 12, 'ojkdfjk')



function deletes(name1,name2,name3,name4) {
    if(user == [key]['id']){
        user[id]['name1'] = name1,
        user[id]['name2'] = name2,
        user[id]['name3'] = name3,
        user[id]['name4'] = name4
    }
}
deletes("abdudsfkja",'idjsfkls','djfkjdf','your')













        









 // ask('asdfsdffd','kdsjfklsdjfkjflsdj,',12,'it')
// function deleteask(tytty,djfdjdfkj){
//     delete user.user1
// }
// ( deleteask("user1",'user2'))
// for( let keys in user){
// console.log();
//  } 
// for (const key in user) {
//     if (user.user1(user, key)) {
//         const element = user[key];
        
//     }
// }
