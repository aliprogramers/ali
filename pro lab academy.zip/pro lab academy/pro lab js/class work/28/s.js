let a = [{ name: 'majid' },
new Set([1, 2, 3, { id: 1,name:'balksdjf', balls: [3, 4, 6, 79] }])]
let [, [, , , {id,...name}]] = a
console.log(name);
function klsdf(ob) {
    
}