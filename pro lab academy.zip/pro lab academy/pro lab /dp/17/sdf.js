let a = [
    {
        0: 'h',
        1: 'e',
        2: 'l'
    }, {
        0: 'w',
        1: 'o',
        2: 'r'
    }
]
// function addnewword(world) {
//     let obj = {}
//     let start = 0
//     for (let item of world) {
//         obj[start] = item
//         start++
//     }
//     a.push(obj)
// }
// addnewword('majid')
// console.log(a);
// function higts(start, world) {
//     // let objs = {}
//     let is = 0
//     for(let key in world){
// is++    
//     }
//     for (let i = start[0] - 1; i < is ; a.includes(world)) {
//         i++
//         console.log('wwewelekjrlwkejrqwlkerjlqwkerjlkqwerjklqwerjqwklrejqwlekrhqwelrhqwewwewelekjrlwkejrqwlkerjlqwkerjlkqwerjklqwerjqwklrejqwlekrhqwelrhqwelhwwewelekjrlwkejrqwlkerjlqwkerjlkqwerjklqwerjqwklrejqwlekrhqwelrhqwelhwwewelekjrlwkejrqwlkerjlqwkerjlkqwerjklqwerjqwklrejqwlekrhqwelrhqwelhwwewelekjrlwkejrqwlkerjlqwkerjlkqwerjklqwerjqwklrejqwlekrhqwelrhqwelhwwewelekjrlwkejrqwlkerjlqwkerjlkqwerjklqwerjqwklrejqwlekrhqwelrhqwelhwwewelekjrlwkejrqwlkerjlqwkerjlkqwerjklqwerjqwklrejqwlekrhqwelrhqwelhwwewelekjrlwkejrqwlkerjlqwkerjlkqwerjklqwerjqwklrejqwlekrhqwelrhqwelhwwewelekjrlwkejrqwlkerjlqwkerjlkqwerjklqwerjqwklrejqwlekrhqwelrhqwelhwwewelekjrlwkejrqwlkerjlqwkerjlkqwerjklqwerjqwklrejqwlekrhqwelrhqwelhwwewelekjrlwkejrqwlkerjlqwkerjlkqwerjklqwerjqwklrejqwlekrhqwelrhqwelhwwewelekjrlwkejrqwlkerjlqwkerjlkqwerjklqwerjqwklrejqwlekrhqwelrhqwelhwwewelekjrlwkejrqwlkerjlqwkerjlkqwerjklqwerjqwklrejqwlekrhqwelrhqwelhwwewelekjrlwkejrqwlkerjlqwkerjlkqwerjklqwerjqwklrejqwlekrhqwelrhqwelhlh');
//         a.splice(i, is, '*')
//     }
//     console.log(is);
// }
// higts(1, 'e')
// console.log(a);
// function higtss(start,buk) {
//     let tot = []
//     let tt = a.length
 
//     for(let i = start[0] -1 ;i < a;i++){
//         console.log('sd');
//         a.splice(i,a,'*')
//     }
//     console.log(a );
// }

// higtss(1, '')
// for (let index = 0; index < array.length; index++) {
//     const element = array[index];

// }
// console.log(a.includes);